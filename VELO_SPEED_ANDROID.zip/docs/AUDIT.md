# Audit complet — VELO SPEED 2.1.0

> **Lecture honnête : ce projet n'a jamais été compilé ni installé pendant cet audit.**
> Aucun SDK Android n'était disponible (dépôts Google/Maven bloqués). Le Kotlin a été **relu à la main deux fois par des relecteurs indépendants**, pas compilé. Aucun APK n'a été construit, aucun test n'a été fait sur un téléphone ni sur le vélo.

## 1. Projet d'origine (ZIP « Python/Kivy »)
Impossible à compiler en l'état, Bluetooth non fiable, UUID/protocoles supposés, vitesse simulée, permissions Android 12+ incorrectes. → Réécriture en Android natif (Kotlin) + interface web locale.

## 2. Architecture
`MainActivity` (WebView verrouillée sur `file:///android_asset/`) · `NativeBridge` (pont JS↔Kotlin, interface `Native`) · `BleController` (scan, connexion GATT, file d'opérations) · `GpsController`. Interface : `assets/www` (lib.js, app-core.js, app-views.js, app-bike.js). Aucune dépendance externe (ni AndroidX, ni bibliothèque Maven).

## 3. Dépendances et versions
| Élément | Version | Remarque |
|---|---|---|
| Android Gradle Plugin | 8.5.2 | exige Gradle ≥ 8.7 |
| Gradle | 8.7 | installé par le workflow (pas de wrapper dans le projet) |
| Kotlin | 1.9.24 | jvmTarget 17 |
| JDK | 17 (Temurin) | installé par le workflow |
| compileSdk / targetSdk / minSdk | 34 / 34 / 23 | Android 6 → 15 |
| Bibliothèques | aucune | stdlib Kotlin seulement |
| Signature | `app/velo-debug.jks` (PKCS12, alias `velo`) | clé de **test**, validité vérifiée |

## 4. Erreurs corrigées pendant l'audit
**Relecture Kotlin/Gradle/Manifest (agent indépendant, aucune erreur de compilation repérée) — défauts d'exécution corrigés :**
1. `Native.vibrate` n'existait pas côté Kotlin (alerte de vitesse sans vibration) → méthode + permission `VIBRATE` ajoutées.
2. `connectGatt` pouvant renvoyer `null` (interface bloquée « connexion… ») → erreur `connect_null`.
3. Découverte des services sans délai ni fermeture en cas d'échec → délai de 10 s, fermeture propre, statut -3.
4. WebView tuée par le système → `onRenderProcessGone` recrée l'écran.
5. `configChanges` incomplet (taille de police, langue, clavier) coupait le Bluetooth → complété.
6. Délai de 6 s trop court quand Android demande l'appairage → 15 s (6 s conservé pour le MTU).
7. État GPS contradictoire (« désactivé » puis « activé ») → état réel émis.
8. Partage GPX/CSV trop gros pour le binder → limité à 100 000 caractères.
9. Connexion avec Bluetooth coupé : attente de 20 s → échec immédiat `bt_off`.
10. `onDestroy` non protégé, WebView détruite encore attachée → corrigé.
11. Appels JS en vol après fermeture pouvant lancer scan/connexion → drapeau `dead`; `applicationContext` pour `connectGatt`.
12. Workflow : tag de release unique (`run_attempt`) et `--target` explicite.
**Corrections antérieures :** garde-fou d'écriture, file GATT (retours tardifs), nouvelle tentative unique après erreur 133 ou délai, scan Android ≤ 11 (localisation système exigée), filtre de navigation API 23, version de l'appli lue depuis le paquet.

## 5. Compatibilité Android 6 → 15
| Android | Permissions demandées | Remarque |
|---|---|---|
| 6–11 (API 23–30) | `ACCESS_FINE_LOCATION` (+ localisation système active pour le scan) ; `BLUETOOTH`, `BLUETOOTH_ADMIN` | détecté et expliqué dans l'appli |
| 12–15 (API 31–35) | `BLUETOOTH_SCAN` (neverForLocation), `BLUETOOTH_CONNECT` ; localisation pour le GPS | signatures GATT API 33+ gérées |
Autres : `INTERNET` (météo), `VIBRATE`. `allowBackup=false`, trafic en clair interdit.

## 6. Configuration Bluetooth
BLE requis (`uses-feature`), GPS facultatif. Connexion `TRANSPORT_LE`, délai 20 s, une seule nouvelle tentative (erreur 133/délai), file d'opérations série avec surveillance, notifications via CCCD, MTU demandé à la demande. **Aucun UUID du A13 n'est codé en dur.**

## 7. Compilation en APK
Voir `COMPILATION.md`. Voie prévue : GitHub Actions (`.github/workflows/build.yml`) → `VELO-SPEED.apk` en Release. **Non exécutée ici.** Risques connus : version de `platforms;android-34`/build-tools sur le runner, avertissements de dépréciation (non bloquants).

## 8. Ce qui a été testé, relu, ou pas
| Élément | État |
|---|---|
| Logique JS (décodage, sommes de contrôle, assistant) | **Testé** (10 tests Node) |
| Interface complète (4 onglets, réglages, verrous de sécurité, trajets, météo, aide) | **Testé en simulateur** (Chromium + faux pont) : couverture lignes lib 82 %, app-core 86 %, app-views 85 %, app-bike 97 % ; 0 erreur JS |
| Code Kotlin (BLE, GPS, pont, WebView) | **Relu seulement** (2 relectures manuelles), **jamais compilé** |
| Manifest, ressources, XML, keystore, Gradle | Vérifiés statiquement (syntaxe, cohérence), **build non exécuté** |
| APK installable | **Non construit** |
| Scan/connexion/services sur un vrai téléphone | **Non testé** |
| Connexion au A13 | **Non testé** |
| Vitesse réelle du vélo par Bluetooth | **Non confirmé** (protocole non public ; le A13 est peut-être une plateforme type Tuya chiffrée, hypothèse non confirmée) |
| Lecture/écriture des limites de vitesse | **Non confirmé, verrouillé** (profil confirmé requis, lecture seule par défaut) |
| GPS réel, vibration, météo réelle, partage de fichiers | **Non testés** sur appareil |

## 9. Limites connues
- Pas de service au premier plan : en arrière-plan prolongé, Android peut suspendre le GPS et le Bluetooth (voir « Stabilité en arrière-plan » dans Réglages).
- Barre de navigation : icônes à contrôler sur appareil.
- `writesAllowed` reste actif jusqu'à la fin de l'écriture JS (refermé dans un `finally`) — pas de fuite connue.
- Aucune modification du vélo n'est faite par défaut ; ne rien modifier pendant les tests.
