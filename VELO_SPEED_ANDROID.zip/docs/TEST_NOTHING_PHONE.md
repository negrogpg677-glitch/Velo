# Protocole de test — Nothing Phone (1) × AVDL A13

**Règle absolue : mode lecture seule actif (par défaut). Aucun paramètre du vélo n'est modifié pendant ces tests.**
Seules opérations Bluetooth effectuées : scan, connexion, découverte des services, lectures, **activation des notifications** (écriture standard du descripteur de notification, qui ne change aucun réglage du vélo) et demande de MTU.
Les valeurs saisies par vous dans YouFs (15 / 25 / 45 / 35 / 35, niveau 5 à 50) ne sont **pas** des réglages d'usine et ne sont pas touchées.

## Préparation
1. Android du Nothing Phone (1) : noter la version (Réglages → À propos). Il est sorti sous Android 12 : le chemin d'autorisations est celui d'Android 12+ (« Appareils à proximité »).
2. Installer l'APK (voir README). Fermer complètement YouFs (une seule connexion Bluetooth à la fois).
3. Réglages → *Stabilité en arrière-plan* → autoriser VELO SPEED sans optimisation de batterie.

## Étapes (cocher et noter le résultat)
| # | Test | Attendu |
|---|---|---|
| 1 | Premier lancement | Présentation, aucun plantage |
| 2 | Vélo → Autoriser | « Appareils à proximité » accordée ; refus puis réessai : bouton des réglages de l'appli |
| 3 | Vélo éteint → Rechercher | Aucun vélo trouvé, pas d'erreur |
| 4 | Vélo allumé → Rechercher | « YouFs-B9 » listé, étiquette « Probable » ; noter « signature Tuya » oui/non |
| 5 | Connecter | « Connecté » en moins de 20 s ; noter les codes d'erreur éventuels (133 ⇒ une nouvelle tentative automatique) |
| 6 | Contrôle de compatibilité | Lister chaque ligne : Vérifié / À faire / Bloquant / Non confirmé |
| 7 | Labo → Générer le rapport | Rapport partagé (**à m'envoyer**) |
| 8 | Labo → Tester le MTU | MTU relevé ou message sans coupure de liaison |
| 9 | Écran éteint 2 min, puis rallumé | Liaison conservée ou reconnexion automatique, sans plantage |
| 10 | Vélo éteint puis rallumé pendant la connexion | Déconnexion détectée, reconnexion possible |
| 11 | Bluetooth coupé puis rallumé | Message clair, pas de plantage |
| 12 | Rotation, retour au bureau, relance de l'appli | État conservé, pas de crash |
| 13 | Trajet GPS 10 min (écran allumé) | Vitesse GPS plausible, trajet enregistré, export GPX |
| 14 | Réglages → Limites (onglet Vélo) | Verrouillé, bandeau « lecture seule actif » |

## À m'envoyer
Rapport de diagnostic (7), journal (Labo → Journal → Partager ; en cas de plantage : « Journal de la session précédente »), version d'Android, résultat de chaque ligne, et la liste du contrôle de compatibilité.

## Critères « stable »
Aucun plantage sur les 14 tests ; connexion réussie en moins de 3 essais ; aucune écriture envoyée (journal sans ligne « Écriture limite ») ; reconnexion automatique fonctionnelle.
