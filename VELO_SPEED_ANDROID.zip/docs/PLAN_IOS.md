# Plan — version iPhone (après stabilisation Android)

**Décision de l'utilisateur** : développer l'iOS seulement quand l'Android est stable et validé sur le vélo.

## Réutilisable
Toute l'interface (`assets/www` : HTML, CSS, JS, tests) et la logique (décodage, assistant, profils, garde-fous). Le pont `Native` (scan, connexion, lecture, notifications, GPS, partage) devient un petit code Swift (WKWebView + CoreBluetooth + CoreLocation) qui respecte le même contrat de messages.

## Différences à traiter
- **CoreBluetooth** n'expose pas l'adresse MAC (identifiant UUID propre à l'iPhone) ni les octets bruts de l'annonce : la détection Tuya et l'analyse d'annonce reposent sur les champs déjà décodés (services annoncés, données constructeur).
- Pas de journal HCI sur l'appareil : la capture Bluetooth passe par un Mac (PacketLogger) ou un profil de journalisation Apple ; sinon utiliser un Android.
- Autorisations : Bluetooth et localisation (textes d'usage obligatoires, en français).
- Arrière-plan : exécution Bluetooth/GPS limitée ; écran allumé recommandé.
- Pas de « sources inconnues » : l'installation passe par Xcode/AltStore (compte gratuit, 7 jours) ou TestFlight (compte développeur payant).

## Compilation sans Mac
Possible via un exécuteur macOS d'intégration continue (GitHub Actions), mais l'installation sur l'iPhone demande un compte Apple et une signature : à voir ensemble le moment venu.

## Prérequis avant de commencer
1. Android validé (protocole `TEST_NOTHING_PHONE.md` réussi).
2. Protocole du vélo établi (Tuya chiffré ou non) : il détermine si la version iPhone aura la vitesse réelle et les limites ou seulement le compteur GPS.
