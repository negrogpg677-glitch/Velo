# Compiler VELO SPEED en APK

> **État honnête :** ce projet n'a **jamais été compilé** par son auteur : l'environnement de développement n'avait ni SDK Android ni accès aux dépôts Maven. Les fichiers Gradle, le manifeste et le Kotlin ont été relus à la main (deux relectures indépendantes) mais **le premier build réel peut révéler des erreurs**. Ce document dit comment les lire et les renvoyer.

## Configuration (versions compatibles entre elles)
| Élément | Version | Raison |
|---|---|---|
| Android Gradle Plugin | 8.5.2 | Exige Gradle ≥ 8.7 et JDK 17 |
| Gradle | 8.7 (épinglé dans le workflow) | Compatible AGP 8.5 |
| Kotlin | 1.9.24 | Compatible AGP 8.5 |
| JDK | 17 (Temurin) | Exigé par AGP 8.x |
| compileSdk / targetSdk | 34 | Android 14 ; l'appli fonctionne aussi sous Android 15 |
| minSdk | 23 | Android 6.0 |
| Dépendances externes | **aucune** (ni AndroidX ni bibliothèque tierce) | Moins de risque de build |
| Signature | `app/velo-debug.jks` (mot de passe `velospeed`) | Clé personnelle fixe : permet les mises à jour par-dessus. **Pas une clé de publication.** |
| `applicationId` | `fr.velospeed.a13` | |

Le dossier ne contient **pas** de « Gradle wrapper » (`gradlew`) : le workflow installe Gradle 8.7 lui-même, et Android Studio sait en générer un.

## Méthode 1 — Depuis le téléphone, avec GitHub (aucun PC)
1. Compte GitHub gratuit → nouveau dépôt **privé**.
2. « Add file → Upload files » : envoyer **tout le contenu** du dossier (y compris le dossier caché `.github`). Si le téléphone ne peut pas envoyer de dossiers cachés, envoyer le zip sous le nom `projet.zip` **et** le fichier `.github/workflows/build.yml` (créé via « Create new file », chemin tapé à la main) : le workflow décompresse `projet.zip` tout seul.
3. Onglet **Actions → Construire l'APK VELO SPEED → Run workflow**. Durée ≈ 5 à 8 min.
4. Succès : onglet **Releases** → `VELO-SPEED.apk` ; ou l'artefact du run.
5. Installer : ouvrir l'APK, autoriser « Installer des applis inconnues » pour le navigateur.

### En cas d'échec
Ouvrir le run en rouge → étape « Compiler » → copier les **lignes commençant par `e:`** (erreurs Kotlin) ou `error:` / `What went wrong` et me les envoyer : je corrige.

## Méthode 2 — Android Studio (PC)
Ouvrir le dossier ; accepter l'installation de la plateforme 34 ; *Build → Build Bundle(s)/APK(s) → Build APK(s)*. APK : `app/build/outputs/apk/debug/app-debug.apk`.

## Méthode 3 — Ligne de commande
JDK 17 + SDK Android 34 (`ANDROID_HOME`), puis `gradle assembleDebug` (Gradle 8.7).

## Risques connus du premier build (non vérifiables ici)
1. Erreur de compilation Kotlin non détectée par la relecture.
2. Plateforme/outils Android 34 absents du runner (le runner GitHub `ubuntu-latest` les fournit normalement, licences acceptées).
3. Avertissements de dépréciation (normaux, sans effet).
