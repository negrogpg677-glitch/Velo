# Tests de VELO SPEED (poste de développement, pas sur le téléphone)

Ils vérifient la **logique JavaScript** et l'**interface** contre un **faux pont Android** (`mock-native.js`).
Ils ne testent NI le code Kotlin, NI le Bluetooth réel, NI un vélo.

Prérequis : Node 18+ et Playwright (`npm i playwright && npx playwright install chromium`).

```
node tests/lib.test.js    # décodage, sommes de contrôle, assistant d'analyse
node tests/e2e.js         # parcours principal + rapport de couverture (tests/couverture.txt)
node tests/e2e2.js        # trajets, exports, erreurs, réglages, entretien, déconnexion
node tests/classic.js     # Bluetooth classique, localisation, signature Tuya
```
