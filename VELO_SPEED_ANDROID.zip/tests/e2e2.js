// Deuxième série : fonctions que la première série n'exerçait pas (voir couverture.txt).
const { chromium, devices } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..', 'app/src/main/assets/www');
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
const srv = http.createServer((q, r) => { const u = q.url.split('?')[0]; const f = path.join(root, u === '/' ? 'index.html' : u); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); r.end(); } else { r.writeHead(200, { 'content-type': types[path.extname(f)] || 'text/plain' }); r.end(d); } }); }).listen(8768);
let fails = 0; const ok = (c, m) => { console.log((c ? 'ok   - ' : 'ECHEC - ') + m); if (!c) fails++; };
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ ...devices['Pixel 7'], deviceScaleFactor: 1 });
  const p = await ctx.newPage(); const errs = [];
  p.on('pageerror', e => errs.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.g|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); });
  await p.route('**/fonts.g*/**', r => r.abort());
  await p.addInitScript({ path: path.join(__dirname, 'mock-native.js') });
  await p.addInitScript(() => { if (!localStorage.getItem('vs_cfg')) localStorage.setItem('vs_cfg', JSON.stringify({ seenIntro: true })); });
  await p.goto('http://localhost:8768/'); await p.waitForTimeout(500);
  const wrap = () => p.evaluate(() => { window.__calls = {}; for (const k of Object.keys(window.Native)) { const o = window.Native[k]; window.Native[k] = function () { window.__calls[k] = (window.__calls[k] || 0) + 1; return o.apply(window.Native, arguments); }; } });
  await wrap();
  const calls = k => p.evaluate(k => (window.__calls[k] || 0), k);
  const txt = s => p.textContent(s);

  // --- trajet : démarrer, pause, reprise, source, plein écran, retour, fin
  await p.evaluate(() => window.__bike.set(18));
  await p.click('#bStart'); await p.waitForTimeout(1500);
  await p.click('#bStart'); ok((await txt('#bStart')) === 'Reprendre', 'pause : le bouton devient « Reprendre »');
  await p.click('#bStart'); ok((await txt('#bStart')) === 'Pause', 'reprise : le bouton devient « Pause »');
  const s0 = await txt('#bSrc'); await p.click('#bSrc'); ok((await txt('#bSrc')) !== s0, 'changement de source');
  await p.click('#bSrc'); await p.click('#bSrc'); ok((await txt('#bSrc')) === s0, 'cycle de source complet');
  await p.click('[data-act=hud-on]'); ok(await p.evaluate(() => document.body.classList.contains('hud')), 'plein écran activé');
  ok((await calls('keepScreenOn')) > 0, 'écran maintenu allumé (appel natif)');
  ok((await p.evaluate(() => window.nativeBack())) === true && !(await p.evaluate(() => document.body.classList.contains('hud'))), 'retour : quitte le plein écran');
  // alerte de vitesse + vibreur natif
  await p.evaluate(() => { VS.cfg.limit = 25; VS.cfg.vib = true; window.__bike.set(31); }); await p.waitForTimeout(1300);
  ok((await txt('#limL')).includes('Au-dessus'), 'alerte de vitesse affichée');
  ok((await calls('vibrate')) >= 1, 'vibreur natif déclenché');
  await p.evaluate(() => window.__bike.set(18)); await p.waitForTimeout(9500);
  await p.click('#bEnd'); await p.waitForTimeout(300);
  ok((await p.evaluate(() => VS.rides.length)) === 1, 'trajet enregistré');

  // --- trajets : détail, GPX, CSV, suppression
  await p.click('[data-tab=rides]'); await p.click('[data-act=ride-open]'); await p.waitForSelector('[data-act=ride-gpx]');
  ok(await p.isVisible('svg.route'), 'tracé affiché dans le détail');
  await p.click('[data-act=ride-gpx]'); const g = await p.evaluate(() => window.__st.shared.pop());
  ok(g && g.x.includes('<gpx') && g.x.includes('<trkpt'), 'export GPX valide (balises gpx/trkpt)');
  await p.click('[data-act=dlg-no]'); await p.click('[data-act=rides-csv]'); const c = await p.evaluate(() => window.__st.shared.pop());
  ok(c && c.x.startsWith('date;duree_s') && c.x.split('\n').length === 2, 'export CSV : en-tête + 1 ligne');
  await p.click('[data-act=ride-open]'); await p.click('[data-act=ride-del]'); await p.click('[data-act=dlg-yes]'); await p.waitForTimeout(300);
  ok((await p.evaluate(() => VS.rides.length)) === 0, 'suppression du trajet');

  // --- messages d'erreur et de connexion : tous en français, aucun vide
  const msgs = await p.evaluate(() => {
    const codes = ['bt_off', 'scanner_null', 'scan_failed', 'permission', 'bad_address', 'discover_failed', 'read_failed', 'op_timeout', 'op_refused', 'op_failed', 'write_blocked', 'bad_hex', 'gps_failed', 'location_off', 'retry_133', 'mtu_timeout'];
    return { e: codes.map(c => [c, VS.errMsg(c, 'x')]), c: [-1, -2, -3, -4, 133, 8, 19, 22, 62, 0].map(s => [s, VS.connMsg(s)]) };
  });
  ok(msgs.e.every(x => x[1] && !/^Erreur /.test(x[1])), 'tous les codes d\'erreur ont un message français : ' + msgs.e.filter(x => !x[1] || /^Erreur /.test(x[1])).map(x => x[0]).join(',') );
  ok(msgs.c.every(x => x[1] && x[1].length > 8), 'tous les codes de connexion ont un message : ' + msgs.c.filter(x => !x[1]).map(x => x[0]).join(','));
  await p.evaluate(() => window.__emit('error', { code: 'bt_off', detail: '' })); await p.waitForTimeout(100);
  ok((await txt('#toast')).includes('Bluetooth est désactivé'), 'erreur native affichée à l\'écran');

  // --- connexion : échec 133, déconnexion volontaire
  await p.click('[data-tab=bike]'); await p.evaluate(() => { window.__st.perms.ble = true; });
  await p.evaluate(() => { VS.cfg.autoReconnect = false; window.__emit('conn', { state: 'failed', status: 133, address: 'AA:BB:CC:DD:EE:01' }); }); await p.waitForTimeout(150);
  ok((await txt('#toast')).includes('133') || (await txt('#toast')).toLowerCase().includes('refus') || (await txt('#toast')).toLowerCase().includes('connexion'), 'échec de connexion (133) : message explicite : ' + (await txt('#toast')));
  await p.click('[data-act=scan-toggle]'); await p.waitForTimeout(300); await p.click('[data-act=bike-connect]'); await p.waitForTimeout(700);
  ok((await txt('#view-bike')).includes('Connecté'), 'reconnexion');
  await p.click('[data-act=bike-disc]'); await p.waitForTimeout(400);
  ok((await txt('#view-bike')).includes('Non connecté') && (await calls('bleDisconnect')) === 1, 'déconnexion volontaire (appel natif + état)');
  await p.evaluate(() => { window.__st.btOff = true; }); await p.evaluate(() => { VS.S.info.bleEnabled = false; VS.show('bike'); });
  // (le faux pont renvoie toujours « activé » : on vérifie seulement l'action native)
  await p.evaluate(() => { VS.acts['bt-enable'](); VS.acts['loc-settings'](); });
  ok((await calls('requestEnableBluetooth')) === 1 && (await calls('openLocationSettings')) === 1, 'actions « activer le Bluetooth » et « réglages de localisation »');

  // --- profil : copier, réinitialiser ; labo : explorer, journal
  await p.click('[data-act=profile-open]'); await p.click('[data-act=profile-copy]'); ok((await calls('copyText')) === 1, 'profil : copie');
  await p.click('[data-act=profile-reset]'); await p.click('[data-act=dlg-yes]'); await p.waitForTimeout(200);
  ok((await p.evaluate(() => VS.profile.confirmed)) === false, 'profil : réinitialisation (non confirmé)');
  await p.evaluate(() => { VS.prevLog = ['ancienne ligne']; }); await p.click('[data-tab=bike]'); await p.click('[data-act=bike-tab][data-t=lab]');
  await p.click('[data-act=plog-copy]'); await p.click('[data-act=plog-share]'); await p.click('[data-act=log-copy]'); await p.click('[data-act=log-share]'); await p.click('[data-act=log-clear]');
  ok((await calls('copyText')) === 3 && (await calls('shareText')) >= 2, 'journaux : copier / partager');

  // --- réglages : unité, entretien, aide, effacement
  await p.click('[data-tab=more]'); await p.selectOption('#cUnits', 'mph'); await p.click('[data-tab=ride]');
  ok((await txt('#unitL')) === 'mph', 'unité mph appliquée au tableau de bord');
  await p.click('[data-tab=more]'); await p.selectOption('#cUnits', 'kmh');
  await p.click('[data-act=mt-add]'); await p.fill('#mtN', 'Test entretien'); await p.fill('#mtE', '123'); await p.click('[data-act=mt-save]');
  ok((await txt('#view-more')).includes('Test entretien'), 'entretien : rappel ajouté');
  await p.locator('[data-act=mt-ok]').last().click(); await p.locator('[data-act=mt-rm]').last().click();
  ok(!(await txt('#view-more')).includes('Test entretien'), 'entretien : « fait » puis suppression');
  for (const a of ['help-ble', 'help-capture', 'help-law', 'intro']) { await p.click('[data-act=' + a + ']'); ok((await txt('.modal')).length > 80, 'aide « ' + a + ' » affichée'); await p.click('[data-act=dlg-no]'); }
  await p.evaluate(() => { VS.store.set('rides', [{ t: 1 }]); });
  await p.click('[data-act=wipe]'); await p.click('[data-act=dlg-yes]'); await p.waitForTimeout(800);
  ok((await p.evaluate(() => VS.rides.length)) === 0 && (await p.evaluate(() => localStorage.getItem('vs_rides'))) === null, 'effacement : trajets supprimés après rechargement');
  console.log(errs.length ? 'ERREURS JS : ' + JSON.stringify(errs) : 'aucune erreur JS'); if (errs.length) fails++;
  console.log(fails ? fails + ' ÉCHEC(S)' : 'TOUS LES TESTS (SÉRIE 2) PASSENT');
  await b.close(); srv.close(); process.exit(fails ? 1 : 0);
})();
