/* Faux pont Android pour tester l'interface dans Chromium. Imite le vrai comportement :
   les écritures sont refusées si bleAllowWrites(true) n'a pas été appelé AVANT l'exécution. */
(function () {
  const B = '-0000-1000-8000-00805f9b34fb';
  const SVC_BAT = '0000180f' + B, CH_BAT = '00002a19' + B, SVC_X = '0000fff0' + B, CH_N = '0000fff1' + B, CH_W = '0000fff2' + B, CH_R = '0000fff3' + B;
  const st = window.__st = { perms: { ble: false, location: false }, connected: false, allow: false, gpsOn: false, limits: [10, 20, 45, 35, 35], speed: 0, notifying: {}, shared: [], writes: [], blocked: 0, badChk: 0 };
  const emit = (t, d) => setTimeout(() => window.onNative && window.onNative(t, d), 0);
  window.__emit = emit;
  const hex = a => a.map(b => (b & 255).toString(16).padStart(2, '0')).join('');
  const unhex = h => { const o = []; for (let i = 0; i < h.length; i += 2) o.push(parseInt(h.substr(i, 2), 16)); return o; };
  let notifT = null, gpsT = null, lat = 48.85, cnt = 0;
  function startNotifLoop() {
    if (notifT) return;
    notifT = setInterval(() => {
      if (!st.connected || !st.notifying[CH_N]) return;
      const raw = Math.round(st.speed * 10);
      emit('value', { service: SVC_X, char: CH_N, hex: hex([0xa5, 1, raw & 255, raw >> 8, 78, (cnt++ * 37) & 255, 0]), kind: 'notify' });
    }, 50);
  }
  window.__bike = {
    sweep(ms) { const t0 = Date.now(); const h = setInterval(() => { const t = (Date.now() - t0) / 1000; st.speed = 17 + 12 * Math.sin(t * 1.3); if (Date.now() - t0 > ms) { clearInterval(h); } }, 40); },
    set(v) { st.speed = v; }
  };
  window.Native = {
    getInfo: () => JSON.stringify({ sdk: st.sdk || 34, android: '14', model: 'Test Pixel', bleSupported: true, bleEnabled: true, permBle: st.perms.ble, permLocation: st.perms.location, appVersion: '2.1.0', locationEnabled: !st.locOff, bonded: st.bonded || [] }),
    lastLocation: () => 'null',
    requestPermissions(kind) { setTimeout(() => { if (st.denyPerms) { emit('perm', { kind, granted: false, blocked: true }); return; } st.perms[kind === 'ble' ? 'ble' : 'location'] = true; emit('perm', { kind, granted: true, blocked: false }); }, 30); },
    vibrate(p) { st.vibes = (st.vibes || 0) + 1; st.lastVibe = p; },
    openAppSettings() { st.appSettings = (st.appSettings || 0) + 1; },
    bleRequestMtu(n) { setTimeout(() => emit('mtu', { mtu: Math.min(n, 185), status: 0 }), 50); },
    openBluetoothSettings() {}, openLocationSettings() {}, requestEnableBluetooth() {},
    bleStartScan() {
      emit('scanState', { scanning: true });
      emit('scan', { name: 'YouFs-B9-TEST', address: 'AA:BB:CC:DD:EE:01', rssi: -55, connectable: true, type: 2, bond: 10, services: [], adv: '02010609' });
      emit('scan', { name: '', address: '11:22:33:44:55:66', rssi: -80, connectable: true, services: [], adv: '' });
      emit('scan', { name: 'Casque JBL', address: '77:88:99:AA:BB:CC', rssi: -70, connectable: true, services: [], adv: '' });
    },
    bleStopScan() { emit('scanState', { scanning: false }); },
    bleConnect(addr) {
      emit('conn', { state: 'connecting', address: addr });
      setTimeout(() => { st.connected = true; emit('conn', { state: 'connected', name: 'YouFs-B9-TEST', address: addr }); }, 100);
      setTimeout(() => emit('services', { services: [
        { uuid: SVC_BAT, characteristics: [{ uuid: CH_BAT, props: ['read', 'notify'] }] },
        { uuid: SVC_X, characteristics: [{ uuid: CH_N, props: ['notify'] }, { uuid: CH_W, props: ['write'] }, { uuid: CH_R, props: ['notify'] }] }] }), 300);
    },
    bleDisconnect() { st.connected = false; st.notifying = {}; emit('conn', { state: 'disconnected', status: 0, address: 'AA:BB:CC:DD:EE:01' }); },
    bleRead(svc, chr) { if (chr === CH_BAT) emit('value', { service: svc, char: chr, hex: '4e', kind: 'read' }); },
    bleNotify(svc, chr, en) { st.notifying[chr] = en; if (chr === CH_N) startNotifLoop(); emit('notifyState', { service: svc, char: chr, enabled: en, status: 0 }); },
    bleAllowWrites(a) { st.allow = a; },
    bleWriteHex(svc, chr, h, resp) {
      setTimeout(() => {
        if (!st.allow) { st.blocked++; emit('error', { code: 'write_blocked', detail: '' }); return; }
        const b = unhex(h); st.writes.push(h);
        if (b[0] === 0xaa && b[1] === 0x56) emit('value', { service: SVC_X, char: CH_R, hex: hex([0xaa].concat(st.limits)), kind: 'notify' });
        else if (b[0] === 0xaa && b[1] === 0x55) {
          if (((b[2] + b[3]) & 255) !== b[4]) st.badChk++; else st.limits[b[2] - 1] = b[3];
        }
        emit('writeResult', { service: svc, char: chr, status: 0 });
      }, 20);
    },
    gpsStart() {
      if (gpsT) return; st.gpsOn = true;
      gpsT = setInterval(() => { lat += st.speed / 3.6 * 0.1 / 111000; emit('gps', { lat, lon: 2.35 + (lat - 48.85) * 0.5, acc: 5, speed: st.speed / 3.6, alt: 42, time: Date.now() }); }, 100);
    },
    gpsStop() { clearInterval(gpsT); gpsT = null; st.gpsOn = false; },
    keepScreenOn() {}, toast() {}, copyText(t) { st.copied = t; }, shareText(t, x) { st.shared.push({ t, x }); }
  };
})();
