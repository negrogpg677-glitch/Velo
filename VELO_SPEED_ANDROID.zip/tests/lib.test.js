const assert = require('assert');
const L = require('../app/src/main/assets/www/lib.js');
let n = 0; const t = (name, fn) => { fn(); n++; console.log('ok -', name); };

t('hex aller-retour', () => { assert.deepStrictEqual(L.hexToBytes('A5 01 ff'), [0xa5, 1, 255]); assert.strictEqual(L.bytesToHex([0xa5, 1, 255]), 'a501ff'); assert.throws(() => L.hexToBytes('abc')); });
t('readField LE/BE/signé', () => {
  assert.strictEqual(L.readField([0x34, 0x12], { offset: 0, len: 2, endian: 'le' }), 0x1234);
  assert.strictEqual(L.readField([0x12, 0x34], { offset: 0, len: 2, endian: 'be' }), 0x1234);
  assert.strictEqual(L.readField([0xff, 0xff], { offset: 0, len: 2, endian: 'le', signed: true }), -1);
  assert.strictEqual(L.readField([1, 2], { offset: 1, len: 2, endian: 'le' }), null);
  assert.strictEqual(L.readField([1, 0, 0, 0x80], { offset: 0, len: 4, endian: 'le' }), 0x80000001);
});
t('decodeSpeed unités', () => {
  assert.ok(Math.abs(L.decodeSpeed([0xfa, 0], { offset: 0, len: 2, endian: 'le', scale: 0.1, unit: 'kmh' }) - 25) < 1e-9);
  assert.ok(Math.abs(L.decodeSpeed([10], { offset: 0, len: 1, endian: 'le', scale: 1, unit: 'ms' }) - 36) < 1e-9);
});
t('CSC vitesse et cadence', () => {
  const c = L.makeCsc(); let rev = 1000, tm = 0, out;
  const frame = () => { const b = [3, rev & 255, (rev >> 8) & 255, 0, 0, tm & 255, (tm >> 8) & 255, (rev / 2) & 255, 0, tm & 255, (tm >> 8) & 255]; return b; };
  c.push(frame(), 2105); rev += 2; tm += 512; out = c.push(frame(), 2105);
  assert.ok(Math.abs(out.speed - 4 * 2.105 * 3.6) < 0.01, 'vitesse ' + out.speed);
  assert.ok(Math.abs(out.cadence - 120) < 0.5, 'cadence ' + out.cadence);
  tm += 512; out = c.push(frame(), 2105); assert.strictEqual(out.speed, 0);
});
t('CSC dépassement de compteur 16 bits', () => {
  const c = L.makeCsc();
  c.push([1, 0xfe, 0, 0, 0, 0xf0, 0xff], 2000);
  const o = c.push([1, 0x02, 0x01, 0, 0, 0x10, 0x00], 2000); // +4 tours en 32/1024 s
  assert.ok(Math.abs(o.speed - (4 * 2) / (32 / 1024) * 3.6) < 0.01);
});
t('sommes de contrôle', () => {
  assert.deepStrictEqual(L.checksum('sum8', [1, 2, 255]), [2]);
  assert.deepStrictEqual(L.checksum('xor8', [1, 2, 3]), [0]);
  assert.deepStrictEqual(L.checksum('crc16_modbus_le', [1, 3, 0, 0, 0, 10]), [0xc5, 0xcd]);
  assert.deepStrictEqual(L.checksum('crc16_modbus_be', [1, 3, 0, 0, 0, 10]), [0xcd, 0xc5]);
  assert.deepStrictEqual(L.checksum('none', [1]), []);
});
t('buildFrame', () => {
  assert.deepStrictEqual(L.buildFrame('AA55 {LEVEL} {VALUE}', { LEVEL: 3, VALUE: 20 }, { kind: 'sum8', from: 2 }), [0xaa, 0x55, 3, 20, 23]);
  assert.deepStrictEqual(L.buildFrame('A5{VALUE:u16le}', { VALUE: 258 }), [0xa5, 2, 1]);
  assert.deepStrictEqual(L.buildFrame('A5{VALUE:u16be}', { VALUE: 258 }), [0xa5, 1, 2]);
  assert.throws(() => L.buildFrame('A5{VALUE}', { VALUE: 300 }));
  assert.throws(() => L.buildFrame('A5{FOO}', {}));
  assert.throws(() => L.buildFrame('A5{VALUE}', { VALUE: -1 }));
});
// Faux vélo : trame [A5, 01, vitesse*10 LE, batterie, compteur aléatoire, ...]. La vitesse est dans les octets 2-3.
function synth(seed, noiseFrames) {
  let s = seed; const rnd = () => (s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296;
  const A = new L.Analyzer(); let t0 = 1_000_000;
  for (let i = 0; i < 240; i++) {               // 240 s à 1 Hz côté GPS
    const v = 12 + 10 * Math.sin(i / 15) + rnd() * 0.4;
    A.addGps(v, t0 + i * 1000);
  }
  for (let t = 0; t < 239000; t += 250) {       // trames à 4 Hz
    const i = t / 1000, v = 12 + 10 * Math.sin(i / 15);
    const raw = Math.round(v * 10);
    const bat = 78, cnt = Math.floor(rnd() * 256);
    A.addFrame('fff1', [0xa5, 0x01, raw & 255, raw >> 8, bat, cnt, 0x00], t0 + t);
    if (noiseFrames) A.addFrame('fff1', [0x5a, 0x02, cnt, 7], t0 + t);
  }
  return A;
}
t('assistant : retrouve le champ vitesse (octets 2-3, LE, ×0,1)', () => {
  const r = synth(7, true).analyze();
  assert.ok(r.ok, r.reason);
  const top = r.candidates[0];
  assert.strictEqual(top.char, 'fff1'); assert.strictEqual(top.offset, 2); assert.strictEqual(top.len, 2); assert.strictEqual(top.endian, 'le');
  assert.ok(Math.abs(top.scale - 0.1) < 0.01, 'échelle ' + top.scale);
  assert.ok(top.r > 0.99);
  // le compteur aléatoire et la batterie constante ne doivent pas être proposés
  assert.ok(!r.candidates.some(c => c.offset === 5 || c.offset === 4));
});
t('assistant : refuse de conclure sans variation de vitesse', () => {
  const A = new L.Analyzer();
  for (let i = 0; i < 60; i++) A.addGps(20 + (i % 2) * 0.1, i * 1000);
  for (let i = 0; i < 100; i++) A.addFrame('fff1', [1, 2, 3], i * 500);
  const r = A.analyze(); assert.strictEqual(r.ok, false); assert.match(r.reason, /pas assez varié/);
});
t('assistant : rien ne ressemble à la vitesse', () => {
  const A = new L.Analyzer(); let s = 3; const rnd = () => (s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296;
  for (let i = 0; i < 120; i++) A.addGps(10 + 10 * Math.sin(i / 9), i * 1000);
  for (let i = 0; i < 300; i++) A.addFrame('fff1', [Math.floor(rnd() * 256), Math.floor(rnd() * 256)], i * 400);
  const r = A.analyze(); assert.strictEqual(r.ok, false);
});
console.log(n + ' tests réussis');
