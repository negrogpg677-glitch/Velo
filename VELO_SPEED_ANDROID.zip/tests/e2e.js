const { chromium, devices } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..', 'app/src/main/assets/www');
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
const srv = http.createServer((q, r) => { const f = path.join(root, q.url.split('?')[0] === '/' ? 'index.html' : q.url.split('?')[0]); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); r.end(); } else { r.writeHead(200, { 'content-type': types[path.extname(f)] || 'text/plain' }); r.end(d); } }); }).listen(8766);
const B = '-0000-1000-8000-00805f9b34fb';
const PROFILE = { name: 'PROFIL DE TEST', confirmed: true, limits: { levels: 5, min: 5, max: 45, levelBase: 1, valueScale: 1,
  read: { command: 'AA5600', service: '0000fff0' + B, writeChar: '0000fff2' + B, char: '0000fff3' + B, fields: [1, 2, 3, 4, 5].map(o => ({ offset: o, len: 1, endian: 'le', scale: 1 })), checksum: { kind: 'none' } },
  write: { service: '0000fff0' + B, char: '0000fff2' + B, template: 'AA55{LEVEL}{VALUE}', withResponse: true, checksum: { kind: 'sum8', from: 2 } } } };
let fails = 0; const ok = (c, m) => { console.log((c ? 'ok   - ' : 'ECHEC - ') + m); if (!c) fails++; };
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ ...devices['Pixel 7'], deviceScaleFactor: 1 });
  const p = await ctx.newPage(); const errs = [];
  await p.coverage.startJSCoverage({ resetOnNavigation: false });
  p.on('pageerror', e => errs.push('PAGEERR ' + e.message));
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.g|ERR_|Failed to load resource/.test(m.text())) errs.push('CONSOLE ' + m.text()); });
  await p.route('**/fonts.g*/**', r => r.abort());
  await p.route('https://api.open-meteo.com/**', r => r.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify({
    current: { time: '2026-11-23T11:00', temperature_2m: 9.4, apparent_temperature: 6.1, wind_speed_10m: 14, wind_direction_10m: 225, weather_code: 3 },
    hourly: { time: Array.from({ length: 48 }, (_, i) => `2026-11-${23 + Math.floor(i / 24)}T${String(i % 24).padStart(2, '0')}:00`), temperature_2m: Array.from({ length: 48 }, (_, i) => 8 + (i % 24) / 6), precipitation_probability: Array.from({ length: 48 }, (_, i) => (i % 24) > 14 ? 40 : 0) },
    daily: { sunset: ['2026-11-23T16:58'], uv_index_max: [1.2] } }) }));
  await p.addInitScript({ path: path.join(__dirname, 'mock-native.js') });
  await p.goto('http://localhost:8766/'); await p.waitForTimeout(600);
  ok(await p.isVisible('.modal'), 'présentation affichée au premier lancement'); await p.click('[data-act=dlg-no]');
  await p.screenshot({ path: 'shot-1-ride.png' });

  // --- Compteur + GPS
  await p.evaluate(() => window.__bike.set(18.4));
  await p.click('#bStart'); await p.waitForTimeout(1800);
  const spd = await p.textContent('#spdI'); ok(spd === '18', 'vitesse GPS affichée (18) : ' + spd);
  ok((await p.textContent('#chSrc')).includes('gps'), 'source GPS');
  await p.waitForTimeout(1200); ok(!(await p.textContent('#sDist')).startsWith('0,00'), 'distance qui augmente : ' + await p.textContent('#sDist'));
  await p.screenshot({ path: 'shot-2-ride-run.png' });

  // --- Vélo : scan, connexion
  await p.click('[data-tab=bike]');
  await p.evaluate(() => { window.__st.denyPerms = true; window.__st.perms.ble = false; });
  await p.click('[data-act=perm-ble]'); await p.waitForTimeout(400);
  ok(await p.isVisible('[data-act=perm-settings]'), 'refus définitif : bouton « Ouvrir les réglages de l\'appli »');
  await p.click('[data-act=perm-settings]'); ok((await p.evaluate(() => window.__st.appSettings)) === 1, 'ouverture des réglages de l\'appli');
  ok((await p.textContent('#view-bike')).includes('Bloquant'), 'contrôle : autorisations signalées bloquantes');
  await p.evaluate(() => { window.__st.denyPerms = false; window.__st.perms.ble = true; });
  await p.click('[data-tab=ride]'); await p.click('[data-tab=bike]');
  await p.click('[data-act=scan-toggle]'); await p.waitForTimeout(400);
  ok((await p.textContent('#view-bike')).includes('Vélo détecté'), 'contrôle de compatibilité affiché');
  const list = await p.textContent('#scanList');
  ok(list.includes('YouFs-B9-TEST') && list.includes('Probable'), 'vélo détecté et marqué « Probable »');
  ok(!list.includes('11:22:33'), 'appareil sans nom masqué par défaut');
  await p.screenshot({ path: 'shot-3-bike-scan.png' });
  await p.click('[data-act=bike-connect]'); await p.waitForTimeout(700);
  ok((await p.textContent('#view-bike')).includes('Connecté'), 'connexion établie');
  ok((await p.textContent('#view-bike')).includes('78'), 'batterie standard lue (78 %)');
  const cv = await p.textContent('#view-bike');
  ok(cv.includes('Non confirmé') && cv.includes('NON CONFIRMÉ : format A13 inconnu'), 'vitesse réelle du vélo : affichée « non confirmée »');
  ok(cv.includes('Services découverts') && /\d+ service/.test(cv), 'services découverts : comptés');

  // --- Limites : bloquées tant que non confirmé
  await p.click('[data-act=bike-tab][data-t=limits]');
  ok(await p.isDisabled('[data-act=lim-apply]'), 'écriture désactivée avec profil non confirmé');
  ok((await p.textContent('#view-bike')).includes('protocole non confirmé'), 'message « non confirmé » visible');
  await p.screenshot({ path: 'shot-4-limits-locked.png' });

  // --- Labo : assistant d'identification
  await p.click('[data-act=bike-tab][data-t=lab]');
  ok((await p.textContent('#view-bike')).includes('fff1'), 'explorateur : caractéristique fff1 listée');
  await p.click('[data-act=mtu-req]'); await p.waitForTimeout(300);
  ok((await p.evaluate(() => VS.S.mtu)) === 185, 'MTU négocié relevé (185)');
  await p.click('[data-act=rec-start]'); await p.evaluate(() => window.__bike.sweep(9000));
  await p.waitForTimeout(9500);
  ok((await p.textContent('#recStat')).includes('trames'), 'statut d\'enregistrement : ' + (await p.textContent('#recStat')));
  await p.click('[data-act=rec-stop]'); await p.waitForTimeout(200);
  const view = await p.textContent('#view-bike');
  ok(view.includes('Meilleur candidat') && view.includes('octets 2 à 3'), 'assistant : champ vitesse retrouvé (octets 2 à 3)');
  await p.screenshot({ path: 'shot-5-lab.png' });
  await p.click('[data-act=cand-use]'); await p.waitForTimeout(300);
  await p.evaluate(() => window.__bike.set(21.3)); await p.waitForTimeout(500);
  await p.click('[data-tab=ride]'); await p.waitForTimeout(700);
  ok((await p.textContent('#chSrc')).includes('vélo'), 'compteur : source vélo (Bluetooth) : ' + await p.textContent('#chSrc'));
  ok(['21', '20'].includes(await p.textContent('#spdI')), 'vitesse décodée depuis le vélo : ' + await p.textContent('#spdI'));

  // --- Profil confirmé de test → écriture des limites
  await p.click('[data-tab=bike]'); await p.click('[data-act=bike-tab][data-t=conn]');
  await p.click('[data-act=profile-open]'); await p.fill('#profTxt', JSON.stringify(PROFILE));
  await p.click('[data-act=profile-save]'); await p.waitForSelector('#dlgCheck');
  ok(await p.isDisabled('#dlgOk'), 'import confirmé : bouton bloqué tant que la case n\'est pas cochée');
  await p.check('#dlgCheck'); await p.click('#dlgOk'); await p.waitForTimeout(300);
  await p.click('[data-act=bike-tab][data-t=limits]');
  ok((await p.textContent('#view-bike')).includes('Mode lecture seule actif'), 'mode lecture seule actif par défaut');
  ok(await p.isDisabled('[data-act=lim-read]'), 'lecture par requête désactivée en lecture seule');
  ok(await p.isDisabled('[data-act=lim-apply][data-level="2"]'), 'écriture impossible en lecture seule');
  await p.click('[data-tab=more]'); await p.waitForTimeout(200);
  await p.click('#cRO'); await p.waitForSelector('#dlgCheck'); ok(await p.isDisabled('#dlgOk'), 'désactiver la lecture seule exige une confirmation');
  await p.check('#dlgCheck'); await p.click('#dlgOk'); await p.waitForTimeout(300);
  ok((await p.evaluate(() => VS.cfg.readOnly)) === false, 'lecture seule désactivée volontairement');
  await p.click('[data-tab=bike]'); await p.click('[data-act=bike-tab][data-t=limits]');
  ok(await p.isDisabled('[data-act=lim-apply][data-level="2"]'), 'écriture verrouillée tant que les niveaux n\'ont pas été lus');
  ok((await p.textContent('#view-bike')).includes('Prérequis avant toute écriture'), 'liste des prérequis affichée');
  await p.click('[data-act=lim-read]'); await p.waitForTimeout(1200);
  ok(!(await p.isDisabled('[data-act=lim-apply][data-level="2"]')), 'écriture armée après lecture et sauvegarde');
  ok((await p.textContent('#view-bike')).includes('Actuel : 45 km/h'), 'limites lues depuis le vélo (niveau 3 = 45)');
  await p.fill('#lv2', '24'); await p.click('[data-act=lim-apply][data-level="2"]'); await p.waitForSelector('#dlgCheck');
  await p.check('#dlgCheck'); await p.click('#dlgOk'); await p.waitForTimeout(2200);
  const s = await p.evaluate(() => ({ l: window.__st.limits, blocked: window.__st.blocked, bad: window.__st.badChk, w: window.__st.writes }));
  ok(s.l[1] === 24, 'écriture appliquée dans le faux vélo (niveau 2 = 24) : ' + JSON.stringify(s.l));
  ok(s.blocked === 0, 'aucune écriture bloquée à tort (course sur le garde-fou) : ' + s.blocked);
  ok(s.bad === 0, 'somme de contrôle valide : trames ' + JSON.stringify(s.w));
  ok((await p.textContent('#view-bike')).includes('vérifié'), 'écriture vérifiée par relecture');
  // > 25 km/h : message terrain privé
  await p.fill('#lv3', '38'); await p.click('[data-act=lim-apply][data-level="3"]'); await p.waitForSelector('#dlgCheck');
  ok((await p.textContent('.modal')).includes('terrain privé'), 'valeur > 25 km/h : avertissement terrain privé');
  await p.screenshot({ path: 'shot-6-limits-warn.png' });
  await p.click('[data-act=dlg-no]');
  const before = await p.evaluate(() => window.__st.limits.slice());
  ok(before[2] === 45, 'annulation : rien n\'est écrit');
  await p.click('[data-act=lim-restore]'); await p.waitForSelector('.modal'); await p.click('[data-act=dlg-yes]'); await p.waitForTimeout(2500);
  ok((await p.evaluate(() => window.__st.limits.join(','))) === '10,20,45,35,35', 'restauration des valeurs d\'origine');

  // --- Rapport de diagnostic
  await p.click('[data-act=bike-tab][data-t=lab]'); await p.click('[data-act=diag-run]'); await p.waitForTimeout(12500);
  const sh = await p.evaluate(() => window.__st.shared.pop());
  ok(sh && sh.x.includes('Services GATT') && sh.x.includes('fff1'), 'rapport de diagnostic généré');
  ok(sh.x.includes('Autorisations Bluetooth : oui') && sh.x.includes('Appareils appairés') && sh.x.includes('MTU : 185'), 'rapport : autorisations, appairage et MTU');

  // --- Fin de trajet, trajets, météo, réglages
  await p.click('[data-tab=ride]'); await p.click('#bEnd'); await p.waitForTimeout(300);
  await p.click('[data-tab=rides]'); await p.waitForTimeout(300);
  ok((await p.textContent('#view-rides')).includes('Distance totale'), 'écran trajets');
  await p.screenshot({ path: 'shot-7-rides.png' });
  await p.click('[data-tab=ride]'); await p.click('#chTemp'); await p.waitForTimeout(500);
  await p.evaluate(() => { window.Native.lastLocation = () => JSON.stringify({ lat: 48.85, lon: 2.35, time: Date.now() }); });
  await p.click('[data-act=wx-refresh]'); await p.waitForTimeout(1200);
  ok((await p.textContent('#view-weather')).includes('Couvert'), 'météo affichée (Couvert)');
  await p.click('[data-act=wx-back]'); ok(await p.isVisible('#spdI'), 'retour au tableau de bord depuis la météo');
  await p.screenshot({ path: 'shot-8-weather.png' });
  await p.click('[data-tab=more]'); await p.waitForTimeout(300);
  ok((await p.textContent('#view-more')).includes('Sécurité des tests') && (await p.textContent('#view-more')).includes('Stabilité en arrière-plan'), 'réglages : sécurité des tests et stabilité');
  await p.screenshot({ path: 'shot-9-more.png' });
  // remonter au compteur pour la capture finale (HUD)
  await p.click('[data-tab=ride]'); await p.waitForTimeout(500); await p.screenshot({ path: 'shot-10-ride-ble.png' });
  await p.emulateMedia({ colorScheme: 'dark' }); await p.waitForTimeout(200); await p.screenshot({ path: 'shot-11-dark.png' });
  ok(await p.evaluate(() => document.querySelectorAll('#nav button').length) === 4, 'navigation : 4 onglets');
  ok(!(await p.evaluate(() => document.body.innerText)).includes('Mochi'), 'plus de mascotte');
  const cov = await p.coverage.stopJSCoverage(); const rep = [];
  for (const e of cov) {
    if (!/\.js$/.test(e.url)) continue;
    const n = e.source.length, hit = new Uint8Array(n);
    for (const f of e.functions) for (const r of f.ranges) hit.fill(r.count > 0 ? 1 : 0, r.startOffset, Math.min(r.endOffset, n));
    const lines = e.source.split('\n'); let off = 0, tot = 0, cv = 0;
    for (const l of lines) { if (l.trim().length > 2 && !/^\s*(\/\/|\/\*|\*)/.test(l)) { tot++; let any = false; for (let i = off; i < off + l.length; i++) if (hit[i]) { any = true; break; } if (any) cv++; } off += l.length + 1; }
    const unNamed = e.functions.filter(f => f.functionName && f.ranges[0].count === 0).map(f => f.functionName);
    rep.push(e.url.split('/').pop() + ' : ' + Math.round(cv / tot * 100) + ' % des lignes exécutées' + (unNamed.length ? ' · fonctions jamais appelées : ' + unNamed.join(', ') : ''));
  }
  fs.writeFileSync(path.join(__dirname, 'couverture.txt'), rep.join('\n') + '\n'); console.log(rep.join('\n'));
  console.log(errs.length ? 'ERREURS JS : ' + JSON.stringify(errs) : 'aucune erreur JS'); if (errs.length) fails++;
  console.log(fails ? fails + ' ÉCHEC(S)' : 'TOUS LES TESTS D\'INTERFACE PASSENT');
  await b.close(); srv.close(); process.exit(fails ? 1 : 0);
})();
